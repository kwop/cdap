name 'cdap_test'
version '0.0.1'

depends 'cdap'
